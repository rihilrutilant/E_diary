const express = require('express');
const bodyParser = require('body-parser');
const twilio = require('twilio'); // We'll use Twilio to send OTP via SMS
const randomstring = require('randomstring'); // We'll use the `randomstring` package to generate random OTP
const dotenv = require('dotenv')

dotenv.config()

const app = express();
app.use(bodyParser.json());

// Store OTPs and their corresponding mobile numbers in a map
const otpMap = new Map();

// Send OTP to the registered mobile number
app.post('/send-otp', async (req, res) => {
    const { mobile } = req.body;

    // Generate a random 6-digit OTP
    const otp = randomstring.generate({ length: 6, charset: 'numeric' });

    try {
        // Send the OTP via SMS using Twilio
        const client = new twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
        await client.messages.create({
            body: `Your OTP is ${otp}`,
            from: '+16812216355',
            to: mobile
        });

        // Store the OTP and its corresponding mobile number in the map
        otpMap.set(mobile, otp);

        // Return success response
        res.status(200).json({ message: 'OTP sent successfully' });
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Failed to send OTP' });
    }
});

app.post('/authenticate', (req, res) => {
    const { mobile, otp } = req.body;

    // Check if the OTP exists for the given mobile number
    if (otpMap.has(mobile)) {
        // Get the stored OTP
        const storedOtp = otpMap.get(mobile);

        // Check if the entered OTP matches the stored OTP
        if (otp === storedOtp) {
            // OTP authentication successful
            res.status(200).json({ message: 'OTP authentication successful' });
        } else {
            // Invalid OTP
            res.status(400).json({ message: 'Invalid OTP' });
        }
    } else {
        // OTP not found for the given mobile number
        res.status(400).json({ message: 'OTP not found for the given mobile number' });
    }
});

app.listen(5050, () => {
    console.log('Server started on port 5050');
});